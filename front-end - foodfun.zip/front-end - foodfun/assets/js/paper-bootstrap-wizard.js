var lanches;
var ingredientes;
var cliente = [];
searchVisible = 0;
transparent = true;



  $(document).ready(function(){
    var inNome = $("#inNome");
    var inMail = $("#inMail");
    var btnRegistrar = $("#btnPedir");
          $.ajax({
                type: "get",
                url: encodeURI("http://localhost:8083/lanches/"),
                dataType: 'json',
                crossDomain: true,
                contentType: "application/json; charset=utf-8"
            }).done(function(data){
                getListaLanche(data);

            });

            function getListaLanche(data){
               lanches = data;
                $.each(lanches, function (index, value) {
                   $('#cardapio').append(`
                       <div class="col-sm-4">
                       <div class="choice" data-toggle="wizard-radio">
                       <input type="radio" name="jobb" value="`+value.id+`">
                       <div class="card card-checkboxes card-hover-effect">
                       <p>`+value.nome+`</p>
                      </div>  </div>  </div>`);
               });
              getIngredientesAdicionais();
            };


          function getIngredientesAdicionais(){
          $.ajax({
              type: "get",
              url: encodeURI("http://localhost:8083/lanches/ingredientes"),
              dataType: 'json',
              crossDomain: true,
              contentType: "application/json; charset=utf-8"
          }).done(function(data){
             getListaIngredientes(data);
          });

          function getListaIngredientes(data){
             ingredientes = data;
             $.each(ingredientes, function (index, value) {
                $('#adicional').append(`
                    <div class="col-sm-4">
                    <div class="choice" data-toggle="wizard-checkbox">
                    <input id= "chk_`+value.id+`"  type="checkbox" name="jobb" value="`+value.id+`">
                    <div class="card card-checkboxes card-hover-effect">
                    <p>`+value.nome+`</p>
                    <input id= "edt_`+value.id+`" type="number" name="quantity" min="1" max="4">
                   </div>  </div>  </div>`);
            });

          };
        };

        function inserirAdicional(lanche,adicional, qtde){

          $.ajax({
              type: "put",
              url: encodeURI("http://localhost:8083/lanches/"+lanche+"/"+adicional+"/"+qtde),
              dataType: 'json',
              crossDomain: true,
              contentType: "application/json; charset=utf-8"
          }).done(function(data){
             cliente.valorFinal = data.valor;

          });

        }

        function excluirAdicional(lanche,adicional, qtde){
          var novoValor = 0;
          $.ajax({
              type: "delete",
              url: encodeURI("http://localhost:8083/lanches/"+lanche+"/"+adicional+"/"+qtde),
              dataType: 'json',
              crossDomain: true,
              contentType: "application/json; charset=utf-8"
          }).done(function(data){
             novoValor = data.valor;
          });
          return novoValor;
        }



            /*  Activate the tooltips      */
            $('[rel="tooltip"]').tooltip();

            // Code for the Validator
            var $validator = $('.wizard-card form').validate({
        		  rules: {
        		    firstname: {
        		      required: true,
        		      minlength: 3
        		    },
        		    lastname: {
        		      required: true,
        		      minlength: 3
        		    },
        		    email: {
        		      required: true
        		    }
                },
        	});


          	$('.wizard-card').bootstrapWizard({
                'tabClass': 'nav nav-pills',
                'nextSelector': '.btn-next',
                'previousSelector': '.btn-previous',

                onNext: function(tab, navigation, index) {
                	var $valid = $('.wizard-card form').valid();
                	if(!$valid) {
                		$validator.focusInvalid();
                		return false;
                	}
                },

                onInit : function(tab, navigation, index){

                  var $total = navigation.find('li').length;
                  $width = 100/$total;

                  navigation.find('li').css('width',$width + '%');

                },

                onTabClick : function(tab, navigation, index){

                    var $valid = $('.wizard-card form').valid();

                    if(!$valid){
                        return false;
                    } else{
                        return true;
                    }

                },

                onTabShow: function(tab, navigation, index) {
                    var $total = navigation.find('li').length;
                    var $current = index+1;

                    var $wizard = navigation.closest('.wizard-card');


                    if($current >= $total) {
                        $($wizard).find('.btn-next').hide();
                        $($wizard).find('.btn-finish').show();
                    } else {
                        $($wizard).find('.btn-next').show();
                        $($wizard).find('.btn-finish').hide();
                    }


                    var move_distance = 100 / $total;
                    move_distance = move_distance * (index) + move_distance / 2;

                    $wizard.find($('.progress-bar')).css({width: move_distance + '%'});
                    //e.relatedTarget // previous tab

                    $wizard.find($('.wizard-card .nav-pills li.active a .icon-circle')).addClass('checked');

                }
	        });



                $('body').on("click",'[data-toggle="wizard-radio"]',function(){
                    wizard = $(this).closest('.wizard-card');
                    wizard.find('[data-toggle="wizard-radio"]').removeClass('active');
                    $(this).addClass('active');
                    $(wizard).find('[type="radio"]').removeAttr('checked');
                    $(this).find('[type="radio"]').attr('checked','true');
                });


                $('body').on("click",'[data-toggle="wizard-checkbox"]',function(){
                    if( $(this).hasClass('active')){
                        $(this).removeClass('active');
                        $(this).find('[type="checkbox"]').removeAttr('checked');
                    } else {
                        $(this).addClass('active');
                        $(this).find('[type="checkbox"]').attr('checked','true');
                    }
                });

                $("input[name = 'next']").click(function(){

                   var listAdicional = [];
                   cliente.nome = inNome.val();
                   cliente.email = inMail.val();
                   cliente.adicional = {};

                    $("input:radio").each(function () {
                         var $this = $(this);
                         if (this.checked) {
                           cliente.lancheSelecionado = this.value -1;
                             // alert(lanches[cliente.lancheSelecionado].nome);
                         }
                    });
                    $("input:checkbox").each(function () {
                          var $this = $(this);
                         if (this.checked) {
                            var ingList = {};
                            ingList.id = this.value -1;
                            ingList.qtde = getQtdeIngrediente(this.value);
                            listAdicional.push(ingList);
                            cliente.adicional = listAdicional;

                            $.each(cliente.adicional,function(i,d){
                              ingredientes[d.id].nome
                                // alert(ingredientes[d.id].nome);
                                // alert(d.qtde);
                            });
                        }
                    });


                    if (cliente.lancheSelecionado >= 0){
                      cliente.valorFinal = currencyFormatted(lanches[cliente.lancheSelecionado].valor,"R$");
                      $('#panelResumo').html("");
                      $('#panelResumo').append(`
                          <div class="col-sm-12" id="idresumo">
                          <p> <strong>Cliente: </strong> ${cliente.nome} </p>
                          <p> <strong>Lanche: </strong> ${lanches[cliente.lancheSelecionado].nome}</p>

                          </div>`);

                        if (cliente.adicional.length >= 0){
                          $('#idresumo').append(`
                          <p><strong>Adicionais: </strong></p>
                          <table class="table table-striped">
                          <thead>
                            <tr>
                              <th>Ingrediente</th>
                              <th>Qtde</th>
                              <th>Valor</th>
                            </tr>
                          </thead>
                          <tbody>`);
                        $.each(cliente.adicional,function(i,d){
                          inserirAdicional(cliente.lancheSelecionado+1,d.id+1,d.qtde);
                           console.log('valor lanche',cliente.valorFinal);
                            $('tbody').append(`
                                <tr>
                                  <td>${ingredientes[d.id].nome} </td>
                                  <td>${d.qtde} </td>
                                  <td>${currencyFormatted(ingredientes[d.id].valor, 'R$')} </td>
                            `);

                        });
                        $('#idresumo').append(`</tbody> </table>`);
                        $('#panelResumo').append(`
                          <div class="col-sm-12">
                          <p> <strong>  Total: </strong> ${cliente.valorFinal}</p>
                        </div>`);
                      }

                    }
          });


                $('.set-full-height').css('height', 'auto');


                btnRegistrar.click(function(){
                  if (cliente.adicional.length > 0){
                      $.each(cliente.adicional,function(i,d){
                          excluirAdicional(cliente.lancheSelecionado+1,d.id+1,d.qtde);
                      });
                      alert('Pedido finalizado!');
                  }

              })

              function getQtdeIngrediente(id){
                var valor = $( "input[type=number][id=edt_"+id+"]").val();
                return valor;
              }

          });



         //Function to show image before upload

        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#wizardPicturePreview').attr('src', e.target.result).fadeIn('slow');
                }
                reader.readAsDataURL(input.files[0]);
            }
        }


        function debounce(func, wait, immediate) {
        	var timeout;
        	return function() {
        		var context = this, args = arguments;
        		clearTimeout(timeout);
        		timeout = setTimeout(function() {
        			timeout = null;
        			if (!immediate) func.apply(context, args);
        		}, wait);
        		if (immediate && !timeout) func.apply(context, args);
        	};
        };

        function currencyFormatted(value, str_cifrao) {
            return str_cifrao + ' ' + value.formatMoney(2, ',', '.');
        }

        Number.prototype.formatMoney = function (c, d, t) {
            var n = this,
                c = isNaN(c = Math.abs(c)) ? 2 : c,
                d = d == undefined ? "." : d,
                t = t == undefined ? "," : t,
                s = n < 0 ? "-" : "",
                i = parseInt(n = Math.abs(+n || 0).toFixed(c)) + "",
                j = (j = i.length) > 3 ? j % 3 : 0;
            return s + (j ? i.substr(0, j) + t : "") + i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + t) + (c ? d + Math.abs(n - i).toFixed(c).slice(2) : "");
        };
